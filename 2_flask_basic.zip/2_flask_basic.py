#!/usr/bin/env python
# coding: utf-8

# ### 풀스택 시작

# In[2]:


from flask import Flask


# => Flask라는 클래스 (대문자)만 import

# In[3]:


app=Flask(__name__) # <= 꼭 인자를 이렇게 써라. 프레임워크가 그렇게 정해져있다. 


# ## __name__이라는 파이썬 문법
# ### => 자동으로 파이썬 해당 모듈의 이름이 저장되게 되어있다.
# ### => 즉, 모듈명을 불러내는 파이썬의 default 매개변수이다. 
# ### => Flas(__name__)으로 설정하여 현재 위치를 flask 객체에 알려줘야함

# #### 해당 파일일 경우 __name__='__main__' 
# #### 모듈로 가져다 쓸 때는 __name__='모듈명'
# #### 여러개의 Flask객체를 만들어서 써야 할 때 서로 구분해야 할 때 app명을 실수하지 않기 위해 __name__디폴트값을 써 준다

# In[4]:


app


# ### 라우팅 경로 설정

# In[14]:


@app.route("/hello") #http://www.fun-coding.org/hello   => 라우팅: hello 를 의미
def hello(): # 함수명 아무거나 써도 됨. 
    return "<h1>Hello World!</h1>" # return 부분에 웹페이지에 보여질 내용들을 작성하면 됨. 


# ### 웹 서버 실행
# - IP와 포트를 옵션으로 넣어줄 수 있음
# - 파이썬이 제공하는 app.run()함수 사용
# - run(host=None, port=None, debug=True)
# - host는 주소, port는 포트번호, debug는 에러정보 

# In[10]:


host_addr= "0.0.0.0"
post_num = "8080"


# In[12]:


app.run(host=host_addr, port=post_num)


# ### 전체 기본 코드

# In[1]:


from flask import Flask
app = Flask(__name__)
@app.route("/hello")
def hello():
    return "<h1>Hello Flask!</h1>"
if __name__ == "__main__": ## 모듈이 아니라면 웹페이지를 띄워라. 
    app.run(host='127.0.0.1',port="8080")


# ### 데코레이터 문법 (파이썬 중급) - @app.route("/hello")

# #### 1. 중첩함수
# - 함수 안에 새로운 함수를 선언하는 것
# - 외부에서 inner_function을 호출할 수 없는 것이 일반적이다

# In[1]:


def outer_func():
    print('call outer_func function')
    
    def inner_func():
        return 'call inner_func function'
    
    print(inner_func())


# In[2]:


outer_func()


# #### 2. First_class function 을 통해 중첩함수를 밖에서 호출 할 수 있음

# In[5]:


def outer_func(num):
    def inner_func():
        print(num)
        return 'complex'
    return inner_func # <---- '함수'를 리턴하는 것임. 
fn = outer_func(10) # <---- First-class function 즉, fn에 함수 형식이 저장됨
print(fn())         # <---- Closure 호출 (함수가 저장되어 있으므로 함수 형식으로 불러냄)


# #### 3. Closure에 대해
# ##### 1)first class함수란
# - FirstClass함수는 함수 자체를 변수에 저장 가능
# - 함수의 인자에 다른 함수를 인수로 전달 가능
# - 함수의 반환 값으로 함수를 전달 가능

# In[4]:


def clac_square(num):
    return num*num

func1=clac_square
func1(2) # <----------------------------여기가 특이!


# In[6]:


def cal_square(num):
    return num*num
def cal_plus(n):
    return n+n
def cal_quad(n):
    return n*n*n*n

def list_square(func,list_):
    result=list()
    for digit in list_:
        result.append(func(digit))
    print (result)
    
num_list=[1,2,3,4,5]

list_square(cal_square,num_list)
list_square(cal_plus,num_list)
list_square(cal_quad,num_list)


# In[7]:


def logger(msg):
    message=msg              #<---------------이 로컬 변수가 살아잇다!!
    def msg_creator():
        print('HighLevel:',message)
    return msg_creator

log1 = logger('Dave Log-in')
print(log1)

log1()

###원ㄹ


# In[8]:


del logger  #<----------------본 함수 삭제!
log1() #<---------------------살아잇다!!


# ### First-class 함수활용

# In[10]:


def html_creator(tag):
    def text_wrapper(msg):
        print('<{0}>{1}</{0}>'.format(tag,msg))
    return text_wrapper

h1_html_creator=html_creator('h1') #1
print(h1_html_creator)
h1_html_creator('안녕')


# ### 중첩함수를 이용하여 목차를 자동 생성해주는 기능 만들기

# In[14]:


def list_wrapper(dot):
    def list_wrapper_inner(list_text):
        for text in list_text:
            print('{0} {1}'.format(dot,text))
    return list_wrapper_inner

fn=list_wrapper('❤')
list_=['윤재일','김복순','윤승주','윤세진']
fn(list_)


# ### Closure Function
# - 외부 함수가 소멸되더라도, 외부 함수 안에 있는 로컬 변수 값과 중첩함수를 사용할 수 있는 기법

# In[15]:


def outer_func(num):
    def inner_func():
        print(num)
        return '안녕'
    return inner_func


# In[16]:


fn=outer_func(10)
fn()


# In[17]:


del outer_func
fn()


# ### 언제 closure를 사용할까?
# - 일반적으로 제공해야할 기능(메소드)이 적은 경우
# - 제공해야할 기능이 많은 경우등은 class를 사용하여 구현

# In[20]:


def cal_power(n):
    def power(digit):
        return digit **n
    return power

fn=cal_power(3)
print(fn(2),fn(3),fn(4))


# ### 1에서 5까지 1승부터 5승까지 출력하기 

# In[8]:


def magic_func(num):
    temp=1
    for a in range(num):
        temp*=num
    return temp
        


# In[6]:


def power_func(num):            #<------------------좀 특이한..!
    def power_func2(digit):
        return digit**num
    return power_func2


# In[108]:


def outer_func(function):
    def inner_func(num):
        result=list()
        for a in range(num):
            result.append(function(a+1))
        return result
    return inner_func


# In[109]:


fn=outer_func(magic_func)


# In[110]:


fn(5)


# In[13]:


list_data = [3,7,2,5,6]
def magic_func(num):
    temp=1
    for a in range(num):
        temp*=num
    return temp
        

def outer_func(function):
    def inner_func(list_):
        list2=list()
        for a in list_:
            list2.append(function(a))     #<----------------- list2 배열의 값 각각이 "Closer 함수"이다.
        return list2
    return inner_func

fn=outer_func(magic_func)
fn(list_data)
        


# In[7]:


list_data=list()
for num in range(1,6): #1~5까지 순서대로
    list_data.append(power_func(num))
    
for func in list_data:
    print(func(2))
    


# ### 데코레이터(Decorator)
# - java Spring에서는 annotation기능으로 활용되고 있다. 
# - 함수 앞, 뒤에 기능을 추가해서 손쉽게 함수를 활용할 수 있는 기법

# In[14]:


# 다음 함수가 정의 되어 있다.
def logger_login():
    return "SJ Login"


# In[16]:


# 시간을 앞뒤로 추가하는 경우
import datetime

def logger_login():
    print(datetime.datetime.now())
    print("SJ Login")
    print(datetime.datetime.now())
    
#  이렇게 일일이 함수를 만들기가 불편하다!!!!!! 
logger_login()   


# ### 데코레이터작성법
# - 중첩함수를 이용한다

# In[19]:


#데코레이터 작성하기
def datetime_decorator(func):
    def wrapper():
        print('time : '+str(datetime.datetime.now()))
        func()
        print(datetime.datetime.now())
    return wrapper    


# In[20]:


#데코레이터 적용하기
@datetime_decorator
def logger_login_anthony():
    print("Anthony login")
logger_login_anthony()


# ### Nested function, Closure function과 함께 데코레이터를 풀어서 작성

# In[26]:


def outer_func(function):
    def inner_func():
        print("decoration added")
        function()
    return inner_func

def log_func():
    print('logging')


# In[24]:


deco=outer_func(log_func)
deco()


# #### 이것을 한번에 데코레이터로 작성하면 다음과 같다

# In[27]:


@outer_func
def log_func():
    print('decorator logging!')
log_func()


# ### 파라미터가 있는 함수에 Decorator 적용하기
# - 중첩함수에 꾸미고자 하는 함수와 동일하게 파라미터를 가져가면 됨

# In[29]:


#데코레이터
def outer_func(function):
    def inner_func(digit1,digit2):
        if digit2==0:                  #<--------------유효성 검사의 예
            print('cannot be divided with zero')
            return 
        function(digit1,digit2)
    return inner_func

# 실제 함수 (function)
def divide(digit1,digit2):
    return digit1/digit2

#데코레이터 사용하기(유효성 검사)
@outer_func
def divide(digit1,digit2):
    print(digit1/digit2)


# In[30]:


divide(9,0)


# In[31]:


divide(4,2)


# In[34]:


fn=outer_func(divide)
fn(6,3)

# 위 식을

@outer_func
def divide(digit1,digit2):
    print(digit1/digit2)
divide(6,3)

# 다음과 같이 decorator로 표현할 수 있다. 
# 위의 예제와 같이 '유효성 체크' 시에도 decorator는 유용하다. 


# In[37]:


def type_checker(function):
    def inner_func(n1,n2):
        if(type(n1)!=int)or(type(n2)!=int):
            print('only integer support')
            return
        return function(n1,n2)
    return inner_func

@type_checker
def multiplexer(digit1,digit2):
    return digit1*digit2

multiplexer(2,2)


# In[43]:


# 다음과 같은 nested function 으로도 동일한 기능을 수행할 수 있다.
def multiplexer(n1,n2):
    return n1*n2

fn=type_checker(multiplexer)
fn(4,3)


# ### 여러 데코레이터 작성하기 
# - 함수에 여러 개의 데코레이터 지정 가능
# - 데코레이터를 나열한 순서대로 실행됨

# In[44]:


def decorator1(function):
    def wrapper():
        print('decorator1')
        function()
    return wrapper

def decorator2(function):
    def wrapper():
        print('decorator2')
        function()
    return wrapper


# In[47]:


@decorator1
@decorator2 # 이 줄 밑에 전부가 @decorator1의 closure function으로 작동한다.
def hello():
    print('hello!')
    
hello()


# In[3]:



        
def text_style(function):
    def inner_text_style(a):
        if(function(a)==True):
            print('올바른 암호문입니다')
            return print('<b>',a,'</b>')
        else:
            print('암호문에는 특수문자와 숫자가 포함되어야 합니다')
            return print('<i>',a,'</i>')
    return inner_text_style


number_list=['1','2','3','4','5','6','7','8','9','0']
special_list=['@','#','$','*','&']

@text_style
def fn(pwd):
    new_list=list()
    new_list2=list()
    new_list3=list()
    for a in pwd:
        new_list.append(a)
    print(new_list)
    def fn2():
        for nl in number_list:
            if (nl in new_list):
                new_list2.append(0)
            else:
                new_list2.append(1)
        return sum(new_list2)
    def fn3():
        for sl in special_list:
            if(sl in new_list):
                new_list3.append(0)
            else:
                new_list3.append(1)
        return sum(new_list3)
    if (fn2()<len(number_list))and(fn3()<len(special_list)):
        return True
    else:
        return False

    
fn('tmdtp3@')


# In[1]:



        
def text_style(function):
    def inner_text_style(a):
        if(function(a)==True):
            print('올바른 암호문입니다')
            return print('<b>',a,'</b>')
        else:
            print('암호문에는 특수문자와 숫자가 포함되어야 합니다')
            return print('<i>',a,'</i>')
    return inner_text_style


number_list=['1','2','3','4','5','6','7','8','9','0']
special_list=['@','#','$','*','&']
@text_style
def val_check(function):
    def fn(pwd):
        new_list=list()
        new_list2=list()
        new_list3=list()
        for a in pwd:
            new_list.append(a)
        print(new_list)
        def fn2():
            for nl in number_list:
                if (nl in new_list):
                    new_list2.append(0)
                else:
                    new_list2.append(1)
            return sum(new_list2)
        def fn3():
            for sl in special_list:
                if(sl in new_list):
                    new_list3.append(0)
                else:
                    new_list3.append(1)
            return sum(new_list3)
        if (fn2()<len(number_list))and(fn3()<len(special_list)):
            return True
        else:
            return False
    return fn


val_check('asd1#f')


# In[254]:


def mark_bold(function):
    def wrapper(*args,**kwargs):
        return '<b>'+function(*args,**kwargs)+'</b>'
    return wrapper
def mark_italic(function):
    def wrapper(*args,**kwargs):
        return '<i>'+function(*args,**kwargs)+'</i>'
    return wrapper

@mark_bold
@mark_italic
def add_html(string):
    return string

print(add_html('안녕하세요'))
        


# ### 메소드 데코레이터
# - 클래스의 method에도 데코레이터 적용 가능하다. 
# - 클레스 method는 첫 파라미터가 self이므로 이 부분을 데코레이터 작성시에 포함시켜야 한다!!!

# In[256]:


#데코레터 작성하기 feat. method
def h1_tag(function):
    def func_wrapper(self,*args,**kwargs):
        return '<h1>{0}</h1>'.format(function(self,*args,**kwargs)) #<----function함수에도 self를 넣어야함!
    return func_wrapper


# In[259]:


class Person:
    def __init__(self,first_name,last_name):
        self.first_name=first_name              #--------------->약간 java의 this 같다 
        self.last_name=last_name
        
    @h1_tag
    def get_name(self):
        return self.first_name+' '+self.last_name


# In[276]:


ysj=Person('Yoon','SeungJu')
print(ysj.get_name())


# In[288]:


def asdf(*args,**b):
    print(args)
    print(b)
asdf(2,3,6,(50),asdf='asdf',fff='fff')


# ### 파라미터가 있는 Decorator 만들기(심화)

# In[11]:


# 중첩 함수를 하나 더 깊게 두어 생성
def decorator1(num):
    def outer_wrapper(function):
        def inner_wrapper(*args,**kwargs):
            print('decorator1{}'.format(num)) #<--------------여기에 데코레이터 인자 사용!
            return function(*args,**kwargs)
        return inner_wrapper
    return outer_wrapper
    


# In[12]:


def print_hello():
    print('hello')
    
print_hello=decorator1(1)(print_hello)


# In[15]:


@decorator1(1)
def print_hello():
    print('hello')
    
print_hello()

